// ----------------------------------------------------------
/*!
	\headerfile
	\title
	\brief Template file files/cppheader/file.h

	\list
	\li @notice Template file classes/file.h
	\li @copyright Arboreus (http://arboreus.systems)
	\li @author Alexandr Kirilov (http://alexandr.kirilov.me)
	\li @created 03/04/2022 at 08:38:20
	\endlist
*/
// ----------------------------------------------------------
#ifndef ALOGGERDATAMODELS_H
#define ALOGGERDATAMODELS_H

// System includes
#include <QDebug>

// Application includes

// Constants and defintions

// Namespace

class ALoggerMessageModel {

	public:

		unsigned long long Time = 0;
		QtMsgType Type = QtMsgType::QtDebugMsg;
		const char* Author = "EMP";
		const char* ThreadID = "NoType";
		const char* Message = "NoMessage";
		const char* Function = "NoFunction";
		const char* File = "NoFile";
		int Line = 0;

		explicit ALoggerMessageModel(void) {}
		virtual ~ALoggerMessageModel(void) {}
};

#endif // ALOGGERDATAMODELS_H
