/* -------------------------------------------------------------------
 *  @doc
 *  @notice Template file wizards/projects/qtquickapplication/main.cpp
 *
 *  @copyright Arboreus (http://arboreus.systems)
 *  @author Alexandr Kirilov (http://alexandr.kirilov.me)
 *  @created 23/05/2023 at 16:02:43
 * */// --------------------------------------------------------------

// System includes

// Precompiled header
#include <mainpch.h>

// Application includes
#include <aloggerglobal.h>
#include <abackend.h>

// Constants
#define A_QML_MAIN "qrc:/Application/Main/Main.qml"

// Qt Quick Application
int main(int inCounter, char* inArguments[]) {

	QGuiApplication oApplication(inCounter, inArguments);
	QQmlApplicationEngine oEngine;

	qInstallMessageHandler(fLoggerMessageHandler);
	_A_DEBUG << "Test";

	ABackend* oBackend = new ABackend(&oEngine);

	const QUrl oURL(QStringLiteral(A_QML_MAIN));
	QObject::connect(
		&oEngine, &QQmlApplicationEngine::objectCreated,
		&oApplication, [oURL](QObject* obj, const QUrl& objUrl) {
			if (!obj && oURL == objUrl) {
				QCoreApplication::exit(-1);
			}
		}, Qt::QueuedConnection
	);
	oEngine.load(oURL);

	return oApplication.exec();
}
