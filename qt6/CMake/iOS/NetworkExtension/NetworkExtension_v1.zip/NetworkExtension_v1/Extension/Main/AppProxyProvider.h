//
//  AppProxyProvider.h
//  NetworkExtensionService
//
//  Created by Alexandr KIRILOV on 26/05/2023.
//

#import <NetworkExtension/NetworkExtension.h>

@interface AppProxyProvider : NEAppProxyProvider

@end
